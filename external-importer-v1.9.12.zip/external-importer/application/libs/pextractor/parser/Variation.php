<?php

namespace ExternalImporter\application\libs\pextractor\parser;

defined('\ABSPATH') || exit;

/**
 * Variation class file
 *
 * @author keywordrush.com <support@keywordrush.com>
 * @link https://www.keywordrush.com
 * @copyright Copyright &copy; 2022 keywordrush.com
 */
class Variation {

    public $attributes = array();

    //public $price;
    //public $oldPrice;
    //public $inStock;
    //public $availability;
}
